create definer = root@localhost trigger auto_set_date_interval_prop_q
    before INSERT
    on property_queue
    for each row
begin
        set
            NEW.queue_time = DATE_ADD(NOW(), INTERVAL 2 HOUR );
    end;

