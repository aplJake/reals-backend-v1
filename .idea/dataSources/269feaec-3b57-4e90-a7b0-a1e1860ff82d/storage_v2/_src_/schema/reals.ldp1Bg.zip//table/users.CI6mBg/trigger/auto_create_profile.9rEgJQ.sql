create definer = root@localhost trigger auto_create_profile
    after INSERT
    on users
    for each row
begin
        insert into reals.user_profile(user_id, profile_description) VALUES (NEW.user_id, '');
    end;

