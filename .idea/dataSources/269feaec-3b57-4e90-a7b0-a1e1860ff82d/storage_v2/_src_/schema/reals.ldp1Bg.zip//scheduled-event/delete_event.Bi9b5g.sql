create definer = root@localhost event delete_event on schedule
    at '2019-06-10 17:31:14'
    enable
    comment '2H interval autoremove from queue'
    do
    BEGIN
    DELETE FROM property_queue WHERE queue_time < DATE_SUB(NOW(), INTERVAL 2 HOUR );
END;

