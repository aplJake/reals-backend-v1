create definer = root@localhost trigger admin_promotion
    after INSERT
    on admins
    for each row
begin
    insert into notifications(user_id, text) values (new.user_id, 'You have been promoted to manager user');
end;

