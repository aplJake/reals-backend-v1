create definer = root@localhost trigger admin_demotion
    after DELETE
    on admins
    for each row
begin
    insert into notifications(user_id, text) values (old.user_id, 'You have been demoted to user');
end;

